#include <iostream>
#include <math.h>

double func(double x, double y)
{
    return -pow(x,2)+5-pow(y,2);
}
float CalculateFloat(int resolution, float minX, float minY, float maxX, float maxY)
{
    float step_x = (maxX-minX)/(float)resolution;
    float step_y = (maxY-minY)/(float)resolution;
    float volume{0.f};

    float z1,z2,z3,z4;
    for(float x = minX; x < maxX;x+=step_x)                                                         //
        for(float y = minY; y<maxY; y+=step_y)                                                      //
        {
            z1=func(x,y);                   //bottom left
            z2=func(x+step_x ,y);           //bottom right
            z3=func(x,y+step_y);            //top left
            z4=func(x+step_x, y+step_y) ;   //top right

            //calculate average heigth of triangle one
            float avg1{(z1+z2+z3)/3.f};
            // calculate volume under first triangle
            volume+=((step_x*step_y)/2.f)*avg1;

            //calculate average heigth of triangle two
            float avg2{(z3+z2+z4)/3.f};
            // calculate volume under second triangle
            volume+=((step_x*step_y)/2.f)*avg2;
        }
    return volume;
}
double CalculateDouble(int resolution, float minX, float minY, float maxX, float maxY)
{
    double step_x = (maxX-minX)/(float)resolution;
    double step_y = (maxY-minY)/(float)resolution;
    double volume{0.f};

    double z1,z2,z3,z4;
    for(float x = minX; x < maxX;x+=step_x)                                                         //
        for(float y = minY; y<maxY; y+=step_y)                                                      //
        {
            z1=func(x,y);                   //bottom left
            z2=func(x+step_x ,y);           //bottom right
            z3=func(x,y+step_y);            //top left
            z4=func(x+step_x, y+step_y) ;   //top right

            //calculate average heigth of triangle one
            double avg1{(z1+z2+z3)/3.f};
            // calculate volume under first triangle
            volume+=((step_x*step_y)/2.f)*avg1;

            //calculate average heigth of triangle two
            double avg2{(z3+z2+z4)/3.f};
            // calculate volume under second triangle
            volume+=((step_x*step_y)/2.f)*avg2;
        }
    return volume;
}


int main()
{
    std::cout << "|| Numerical approx of function  ||\n";
    std::cout << "|| resolution\t || output float || output double\n";
    std::cout << "|| 100\t\t || " << CalculateFloat(100,-2,-2,2,2) << "\t || " << CalculateDouble(100,-2,-2,2,2)<< "\n";
    std::cout << "|| 200\t\t || " << CalculateFloat(200,-2,-2,2,2) << "\t || "<< CalculateDouble(200,-2,-2,2,2)<< "\n";
    std::cout << "|| 2000\t\t || " << CalculateFloat(2000,-2,-2,2,2) << "\t || "<< CalculateDouble(2000,-2,-2,2,2)<< "\n";
    std::cout << "|| 8000\t\t || " << CalculateFloat(8000,-2,-2,2,2) << "\t\t || "<< CalculateDouble(8000,-2,-2,2,2)<< "\n";
    return 0;
}
